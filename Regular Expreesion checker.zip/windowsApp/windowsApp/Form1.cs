using System.Linq;
using System.Text.RegularExpressions;
// Regular Expression - for matching patterns
// Regex class handles Regular Expression
namespace windowsApp
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            // taking both text and pattern from input
           String t = text.Text.ToString();  
           String p = pattern.Text.ToString();


            Regex reg = new Regex( p );//^(carrot)->beginning of string , $->end of string
            // reg types
            //[a-z] : anything b/w a-z of single character
            // ^[a-z]$ : checks at both beginning and end
            // [a-z]{5} : checks 5 character in between range if less than 5 false
            // ^[a-z]{1,5}$ " for 5 characters it can take 1 character till 5 character as input
            // gmail validator : ^[a-zA-z0-9]{5,20}@[a-zA-z]{5,10}.[a-zA-z]{3,5}$
            // or                ^[a-zA-z0-9]{5,20}@[a-zA-z]{5,10}.{co|com|in|us}$
            bool r = reg.IsMatch( t );
           
                result.Text = "Result : "+ r.ToString();
            
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }
    }


}