﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace windowsApp
{
    internal class Class1 : Exception // for throw and raise exception we inherit this
    {
        public Class1() { }

        public Class1(String message) : base(message)
        {

        }
        public Class1(String message , Exception ex) : base(message, ex)
        {

        }
    }
}
